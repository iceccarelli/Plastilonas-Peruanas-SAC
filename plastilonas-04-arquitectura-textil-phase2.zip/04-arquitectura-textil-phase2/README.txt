PLASTILONAS PERUANAS SAC — Trilogy Phase 2 (cinematic second frame)
Pair each file with the matching Phase 1 master (same name without -02).
Phase 1 = establishing shot. Phase 2 = new angle / zoom / interior / hero detail.
Official mark + the words “Plastilonas Peruanas” on every frame.
Application scenes remain referential.
