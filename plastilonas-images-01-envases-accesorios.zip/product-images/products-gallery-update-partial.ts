// =============================================================================
// PARTIAL GALLERY UPDATE – ZIP 1: Envases + Accesorios
// Paste / merge into the corresponding product objects in lib/products.ts
// Paths assume images are placed under public/images/ (adjust if nested folders kept)
// =============================================================================

// --- big-bags-bolsones-polipropileno ---
/*
  image: '/images/big-bags-bolsones-polipropileno-1.jpg',
  gallery: [
    '/images/big-bags-bolsones-polipropileno-1.jpg',
    '/images/big-bags-bolsones-polipropileno-2.jpg',
    '/images/big-bags-bolsones-polipropileno-3.jpg',
    '/images/big-bags-bolsones-polipropileno-4.jpg',
  ],
*/

// --- sacos-polytarp-embarque-granel ---
/*
  image: '/images/sacos-polytarp-embarque-granel-1.jpg',
  gallery: [
    '/images/sacos-polytarp-embarque-granel-1.jpg',
    '/images/sacos-polytarp-embarque-granel-2.jpg',
    '/images/sacos-polytarp-embarque-granel-3.jpg',
    '/images/sacos-polytarp-embarque-granel-4.jpg',
  ],
*/

// --- bolsas-laminas-pebd-pead ---
/*
  image: '/images/bolsas-laminas-pebd-pead-1.jpg',
  gallery: [
    '/images/bolsas-laminas-pebd-pead-1.jpg',
    '/images/bolsas-laminas-pebd-pead-2.jpg',
    '/images/bolsas-laminas-pebd-pead-3.jpg',
    '/images/bolsas-laminas-pebd-pead-4.jpg',
  ],
*/

// --- films-termocontraibles-shrink ---
/*
  image: '/images/films-termocontraibles-shrink-1.jpg',
  gallery: [
    '/images/films-termocontraibles-shrink-1.jpg',
    '/images/films-termocontraibles-shrink-2.jpg',
    '/images/films-termocontraibles-shrink-3.jpg',
    '/images/films-termocontraibles-shrink-4.jpg',
  ],
*/

// --- accesorios-instalacion ---
/*
  image: '/images/accesorios-instalacion-1.jpg',
  gallery: [
    '/images/accesorios-instalacion-1.jpg',
    '/images/accesorios-instalacion-2.jpg',
    '/images/accesorios-instalacion-3.jpg',
    '/images/accesorios-instalacion-4.jpg',
  ],
*/
