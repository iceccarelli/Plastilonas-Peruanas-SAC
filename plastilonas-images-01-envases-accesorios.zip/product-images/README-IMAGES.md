# Plastilonas Peruanas SAC – Image Assets ZIP 1
## Envases + Accesorios

Generated: 2026-07-23
Style: Photorealistic industrial / architectural / agricultural photography for Peruvian mining, construction and agri clients.
Color grade: clean, slightly desaturated, modern.
Aspect: landscape ~3:2 (1920×1280), progressive JPG, quality optimized for web (~150-230 KB each).

### Contents (20 images)

#### Family: envases-embalaje

**big-bags-bolsones-polipropileno** (Big Bags / Bolsones de Polipropileno)
- big-bags-bolsones-polipropileno-1.jpg  → Hero / context (mining yard stacks)
- big-bags-bolsones-polipropileno-2.jpg  → Detail / material close-up (weave, ojalillos, seams)
- big-bags-bolsones-polipropileno-3.jpg  → Installation / fabrication (workers sewing)
- big-bags-bolsones-polipropileno-4.jpg  → Finished / scale (large yard stacks + truck)

**sacos-polytarp-embarque-granel** (Sacos Polytarp para Embarque a Granel)
- sacos-polytarp-embarque-granel-1.jpg  → Hero / context (port loading with ship)
- sacos-polytarp-embarque-granel-2.jpg  → Detail / material close-up (Polytarp texture + eyelets)
- sacos-polytarp-embarque-granel-3.jpg  → Installation / fabrication (sewing line)
- sacos-polytarp-embarque-granel-4.jpg  → Finished / scale (warehouse + truck loading)

**bolsas-laminas-pebd-pead** (Bolsas y Láminas de Polietileno PEBD / PEAD)
- bolsas-laminas-pebd-pead-1.jpg  → Hero / context (warehouse rolls)
- bolsas-laminas-pebd-pead-2.jpg  → Detail / material close-up (PE film roll)
- bolsas-laminas-pebd-pead-3.jpg  → Installation / fabrication (production line)
- bolsas-laminas-pebd-pead-4.jpg  → Finished / scale (field / yard stacks)

**films-termocontraibles-shrink** (Films Termocontraíbles (Shrink) y Mangas PE)
- films-termocontraibles-shrink-1.jpg  → Hero / context (warehouse rolls)
- films-termocontraibles-shrink-2.jpg  → Detail / material close-up (clear shrink film)
- films-termocontraibles-shrink-3.jpg  → Installation / fabrication (shrink line workers)
- films-termocontraibles-shrink-4.jpg  → Finished / scale (pallet wrapping)

#### Family: accesorios

**accesorios-instalacion** (Accesorios de Instalación – Ojalillos, Sogas, Tensores, Tubos)
- accesorios-instalacion-1.jpg  → Hero / context (accessories + tarp installation)
- accesorios-instalacion-2.jpg  → Detail / material close-up (eyelets, ropes, tubes)
- accesorios-instalacion-3.jpg  → Installation / fabrication (workers tensioning)
- accesorios-instalacion-4.jpg  → Finished / scale (installed cover with tension system)

### Suggested gallery arrays (also in products-gallery-update-partial.ts)

See the accompanying TypeScript file for ready-to-paste snippets matching the current lib/products.ts structure.

### Usage
1. Unzip into the project root or merge the `product-images/` tree into `public/images/` (flatten or keep folders as preferred by next/image paths).
2. Update gallery fields in `lib/products.ts` using the partials provided.
3. All filenames are already lowercase-hyphenated and ready for `/images/...` paths.
