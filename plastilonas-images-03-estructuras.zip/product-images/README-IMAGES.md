# Plastilonas Peruanas SAC – Image Assets ZIP 3
## Estructuras y Arquitectura Textil

Generated: 2026-07-23
Style: Photorealistic industrial / architectural photography for Peruvian mining, construction and agri clients.
Color grade: clean, slightly desaturated, modern.
Aspect: landscape ~3:2 (1920×1280), progressive JPG, web-optimized.

### Contents (24 images)

#### Family: estructuras

**carpas-lona-estructuras-metalicas** (Carpas de Lona Plástica con Estructuras Metálicas)
- carpas-lona-estructuras-metalicas-1.jpg → Hero / context (interior of metal-framed tent)
- carpas-lona-estructuras-metalicas-2.jpg → Detail / material (fabric + metal joints)
- carpas-lona-estructuras-metalicas-3.jpg → Installation (workers assembling frame)
- carpas-lona-estructuras-metalicas-4.jpg → Scale (camp of finished tents)

**coberturas-tensionadas-arquitectura-textil** (Coberturas Tensionadas y Arquitectura Textil)
- coberturas-tensionadas-arquitectura-textil-1.jpg → Hero / context (tensioned membrane roof)
- coberturas-tensionadas-arquitectura-textil-2.jpg → Detail / material (central hub + cables)
- coberturas-tensionadas-arquitectura-textil-3.jpg → Installation (workers on scaffolding)
- coberturas-tensionadas-arquitectura-textil-4.jpg → Scale (finished architectural structure)

**coberturas-inflables** (Coberturas y Estructuras Inflables)
- coberturas-inflables-1.jpg → Hero / context (row of inflatable structures)
- coberturas-inflables-2.jpg → Detail / material (fabric seams + valves)
- coberturas-inflables-3.jpg → Installation (workers inflating)
- coberturas-inflables-4.jpg → Scale (large dome structure)

**modulos-albergues-campamentos** (Módulos y Albergues para Campamentos)
- modulos-albergues-campamentos-1.jpg → Hero / context (mining camp modules)
- modulos-albergues-campamentos-2.jpg → Detail / material (frame + fabric joint)
- modulos-albergues-campamentos-3.jpg → Installation (workers assembling modules)
- modulos-albergues-campamentos-4.jpg → Scale (finished camp cluster)

**galpones-invernaderos-estructurados** (Galpones, Techos Ligeros e Invernaderos Estructurados)
- galpones-invernaderos-estructurados-1.jpg → Hero / context (greenhouse complex)
- galpones-invernaderos-estructurados-2.jpg → Detail / material (frame + film clips)
- galpones-invernaderos-estructurados-3.jpg → Installation (workers covering tunnels)
- galpones-invernaderos-estructurados-4.jpg → Scale (finished greenhouse range)

**toldos-cerramientos** (Toldos, Cerramientos y Cortinas Industriales)
- toldos-cerramientos-1.jpg → Hero / context (industrial curtain partitions)
- toldos-cerramientos-2.jpg → Detail / material (track + rollers)
- toldos-cerramientos-3.jpg → Installation (workers hanging curtains)
- toldos-cerramientos-4.jpg → Scale (large factory dividers)

### Suggested gallery arrays
See products-gallery-update-partial.ts

### Usage
Unzip and merge into public/images/. Update lib/products.ts with the partials.
