// =============================================================================
// PARTIAL GALLERY UPDATE – ZIP 3: Estructuras y Arquitectura Textil
// Paste / merge into the corresponding product objects in lib/products.ts
// Paths assume images under public/images/
// =============================================================================

// --- carpas-lona-estructuras-metalicas ---
/*
  image: '/images/carpas-lona-estructuras-metalicas-1.jpg',
  gallery: [
    '/images/carpas-lona-estructuras-metalicas-1.jpg',
    '/images/carpas-lona-estructuras-metalicas-2.jpg',
    '/images/carpas-lona-estructuras-metalicas-3.jpg',
    '/images/carpas-lona-estructuras-metalicas-4.jpg',
  ],
*/

// --- coberturas-tensionadas-arquitectura-textil ---
/*
  image: '/images/coberturas-tensionadas-arquitectura-textil-1.jpg',
  gallery: [
    '/images/coberturas-tensionadas-arquitectura-textil-1.jpg',
    '/images/coberturas-tensionadas-arquitectura-textil-2.jpg',
    '/images/coberturas-tensionadas-arquitectura-textil-3.jpg',
    '/images/coberturas-tensionadas-arquitectura-textil-4.jpg',
  ],
*/

// --- coberturas-inflables ---
/*
  image: '/images/coberturas-inflables-1.jpg',
  gallery: [
    '/images/coberturas-inflables-1.jpg',
    '/images/coberturas-inflables-2.jpg',
    '/images/coberturas-inflables-3.jpg',
    '/images/coberturas-inflables-4.jpg',
  ],
*/

// --- modulos-albergues-campamentos ---
/*
  image: '/images/modulos-albergues-campamentos-1.jpg',
  gallery: [
    '/images/modulos-albergues-campamentos-1.jpg',
    '/images/modulos-albergues-campamentos-2.jpg',
    '/images/modulos-albergues-campamentos-3.jpg',
    '/images/modulos-albergues-campamentos-4.jpg',
  ],
*/

// --- galpones-invernaderos-estructurados ---
/*
  image: '/images/galpones-invernaderos-estructurados-1.jpg',
  gallery: [
    '/images/galpones-invernaderos-estructurados-1.jpg',
    '/images/galpones-invernaderos-estructurados-2.jpg',
    '/images/galpones-invernaderos-estructurados-3.jpg',
    '/images/galpones-invernaderos-estructurados-4.jpg',
  ],
*/

// --- toldos-cerramientos ---
/*
  image: '/images/toldos-cerramientos-1.jpg',
  gallery: [
    '/images/toldos-cerramientos-1.jpg',
    '/images/toldos-cerramientos-2.jpg',
    '/images/toldos-cerramientos-3.jpg',
    '/images/toldos-cerramientos-4.jpg',
  ],
*/
