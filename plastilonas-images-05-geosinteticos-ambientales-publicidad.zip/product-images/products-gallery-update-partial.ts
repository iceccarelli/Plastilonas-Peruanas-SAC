// =============================================================================
// PARTIAL GALLERY UPDATE – ZIP 5: Geosintéticos + Ambientales + Publicidad
// Paste / merge into the corresponding product objects in lib/products.ts
// Paths assume images under public/images/
// =============================================================================

// --- geomembranas-hdpe-ldpe ---
/*
  image: '/images/geomembranas-hdpe-ldpe-1.jpg',
  gallery: [
    '/images/geomembranas-hdpe-ldpe-1.jpg',
    '/images/geomembranas-hdpe-ldpe-2.jpg',
    '/images/geomembranas-hdpe-ldpe-3.jpg',
    '/images/geomembranas-hdpe-ldpe-4.jpg',
  ],
*/

// --- geotextiles-no-tejidos ---
/*
  image: '/images/geotextiles-no-tejidos-1.jpg',
  gallery: [
    '/images/geotextiles-no-tejidos-1.jpg',
    '/images/geotextiles-no-tejidos-2.jpg',
    '/images/geotextiles-no-tejidos-3.jpg',
    '/images/geotextiles-no-tejidos-4.jpg',
  ],
*/

// --- geocompuestos-drenaje ---
/*
  image: '/images/geocompuestos-drenaje-1.jpg',
  gallery: [
    '/images/geocompuestos-drenaje-1.jpg',
    '/images/geocompuestos-drenaje-2.jpg',
    '/images/geocompuestos-drenaje-3.jpg',
    '/images/geocompuestos-drenaje-4.jpg',
  ],
*/

// --- barreras-acusticas ---
/*
  image: '/images/barreras-acusticas-1.jpg',
  gallery: [
    '/images/barreras-acusticas-1.jpg',
    '/images/barreras-acusticas-2.jpg',
    '/images/barreras-acusticas-3.jpg',
    '/images/barreras-acusticas-4.jpg',
  ],
*/

// --- lonas-publicitarias ---
/*
  image: '/images/lonas-publicitarias-1.jpg',
  gallery: [
    '/images/lonas-publicitarias-1.jpg',
    '/images/lonas-publicitarias-2.jpg',
    '/images/lonas-publicitarias-3.jpg',
    '/images/lonas-publicitarias-4.jpg',
  ],
*/

// --- banners-gigantografias ---
/*
  image: '/images/banners-gigantografias-1.jpg',
  gallery: [
    '/images/banners-gigantografias-1.jpg',
    '/images/banners-gigantografias-2.jpg',
    '/images/banners-gigantografias-3.jpg',
    '/images/banners-gigantografias-4.jpg',
  ],
*/
