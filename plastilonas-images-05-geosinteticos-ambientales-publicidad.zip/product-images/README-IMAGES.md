# Plastilonas Peruanas SAC – Image Assets ZIP 5
## Geosintéticos + Ambientales + Publicidad

Generated: 2026-07-23
Style: Photorealistic industrial / environmental / commercial photography for Peruvian mining, construction and agri clients.
Color grade: clean, slightly desaturated, modern.
Aspect: landscape ~3:2 (1920×1280), progressive JPG, web-optimized.

### Contents (24 images)

#### Family: geosinteticos-ambientales-publicidad

**geomembranas-hdpe-ldpe** (Geomembranas de HDPE / LDPE)
- geomembranas-hdpe-ldpe-1.jpg → Hero / context (landfill liner)
- geomembranas-hdpe-ldpe-2.jpg → Detail / material (welded seam)
- geomembranas-hdpe-ldpe-3.jpg → Installation (workers welding)
- geomembranas-hdpe-ldpe-4.jpg → Scale (finished pond liner)

**geotextiles-no-tejidos** (Geotextiles No Tejidos)
- geotextiles-no-tejidos-1.jpg → Hero / context (rolls on site)
- geotextiles-no-tejidos-2.jpg → Detail / material (fiber texture)
- geotextiles-no-tejidos-3.jpg → Installation (workers unrolling)
- geotextiles-no-tejidos-4.jpg → Scale (large coverage)

**geocompuestos-drenaje** (Geocompuestos de Drenaje)
- geocompuestos-drenaje-1.jpg → Hero / context (drainage mats)
- geocompuestos-drenaje-2.jpg → Detail / material (core + geotextile)
- geocompuestos-drenaje-3.jpg → Installation (workers placing)
- geocompuestos-drenaje-4.jpg → Scale (slope coverage)

**barreras-acusticas** (Barreras Acústicas)
- barreras-acusticas-1.jpg → Hero / context (road barriers)
- barreras-acusticas-2.jpg → Detail / material (absorption surface)
- barreras-acusticas-3.jpg → Installation (workers placing panels)
- barreras-acusticas-4.jpg → Scale (long barrier wall)

**lonas-publicitarias** (Lonas Publicitarias)
- lonas-publicitarias-1.jpg → Hero / context (building facade)
- lonas-publicitarias-2.jpg → Detail / material (grommets + fabric)
- lonas-publicitarias-3.jpg → Installation (workers hanging)
- lonas-publicitarias-4.jpg → Scale (large blank tarp)

**banners-gigantografias** (Banners y Gigantografías)
- banners-gigantografias-1.jpg → Hero / context (scaffolding banners)
- banners-gigantografias-2.jpg → Detail / material (print surface + grommets)
- banners-gigantografias-3.jpg → Installation (workers on scaffold)
- banners-gigantografias-4.jpg → Scale (building wrap)

### Suggested gallery arrays
See products-gallery-update-partial.ts

### Usage
Unzip and merge into public/images/. Update lib/products.ts with the partials.
