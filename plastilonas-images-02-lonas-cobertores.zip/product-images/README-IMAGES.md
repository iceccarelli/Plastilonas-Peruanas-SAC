# Plastilonas Peruanas SAC – Image Assets ZIP 2
## Lonas y Cobertores

Generated: 2026-07-23
Style: Photorealistic industrial / architectural / agricultural photography for Peruvian mining, construction, transport and agri clients.
Color grade: clean, slightly desaturated, modern.
Aspect: landscape ~3:2 (1920×1280), progressive JPG, web-optimized.

### Contents (24 images)

#### Family: lonas-cobertores

**lona-plastificada-rafia-polytarp** (Lona Plastificada, Rafia y Polytarp a Medida)
- lona-plastificada-rafia-polytarp-1.jpg → Hero / context (mining site covers)
- lona-plastificada-rafia-polytarp-2.jpg → Detail / material (mesh + ojalillos)
- lona-plastificada-rafia-polytarp-3.jpg → Fabrication (sewing workshop)
- lona-plastificada-rafia-polytarp-4.jpg → Scale (covered equipment yard)

**mantas-cobertores-toldos-camiones** (Mantas Cobertores y Toldos para Camiones)
- mantas-cobertores-toldos-camiones-1.jpg → Hero / context (truck yard)
- mantas-cobertores-toldos-camiones-2.jpg → Detail / material (tarp texture + eyelet)
- mantas-cobertores-toldos-camiones-3.jpg → Installation (workers fitting on truck)
- mantas-cobertores-toldos-camiones-4.jpg → Scale (line of covered trucks)

**siders-tolderas-camiones** (Siders y Tolderas para Camiones)
- siders-tolderas-camiones-1.jpg → Hero / context (side curtains on trailers)
- siders-tolderas-camiones-2.jpg → Detail / material (PVC + hardware)
- siders-tolderas-camiones-3.jpg → Installation (workers mounting on chassis)
- siders-tolderas-camiones-4.jpg → Scale (finished truck with open side)

**cobertores-agricolas-multimaterial** (Cobertores Multimaterial)
- cobertores-agricolas-multimaterial-1.jpg → Hero / context (field greenhouses)
- cobertores-agricolas-multimaterial-2.jpg → Detail / material (mesh layers)
- cobertores-agricolas-multimaterial-3.jpg → Installation (workers deploying covers)
- cobertores-agricolas-multimaterial-4.jpg → Scale (interior of covered greenhouse)

**mantas-arpilleras-granjas** (Mantas Arpilleras para Granjas)
- mantas-arpilleras-granjas-1.jpg → Hero / context (covered farm bales)
- mantas-arpilleras-granjas-2.jpg → Detail / material (hessian weave)
- mantas-arpilleras-granjas-3.jpg → Installation (workers in farm structure)
- mantas-arpilleras-granjas-4.jpg → Scale (farm yard with covers)

**mantas-aislantes-termicas-termoacusticas** (Mantas Aislantes Térmicas y Termoacústicas)
- mantas-aislantes-termicas-termoacusticas-1.jpg → Hero / context (industrial insulation stacks)
- mantas-aislantes-termicas-termoacusticas-2.jpg → Detail / material (layered insulation)
- mantas-aislantes-termicas-termoacusticas-3.jpg → Installation (workers on industrial pipes)
- mantas-aislantes-termicas-termoacusticas-4.jpg → Scale (insulated equipment)

### Suggested gallery arrays
See products-gallery-update-partial.ts for ready-to-paste snippets.

### Usage
Unzip and merge into public/images/ (or keep nested folders and adjust paths). Update lib/products.ts gallery fields with the partials.
