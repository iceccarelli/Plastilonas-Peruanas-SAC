// =============================================================================
// PARTIAL GALLERY UPDATE – ZIP 2: Lonas y Cobertores
// Paste / merge into the corresponding product objects in lib/products.ts
// Paths assume images under public/images/ (adjust if nested)
// =============================================================================

// --- lona-plastificada-rafia-polytarp ---
/*
  image: '/images/lona-plastificada-rafia-polytarp-1.jpg',
  gallery: [
    '/images/lona-plastificada-rafia-polytarp-1.jpg',
    '/images/lona-plastificada-rafia-polytarp-2.jpg',
    '/images/lona-plastificada-rafia-polytarp-3.jpg',
    '/images/lona-plastificada-rafia-polytarp-4.jpg',
  ],
*/

// --- mantas-cobertores-toldos-camiones ---
/*
  image: '/images/mantas-cobertores-toldos-camiones-1.jpg',
  gallery: [
    '/images/mantas-cobertores-toldos-camiones-1.jpg',
    '/images/mantas-cobertores-toldos-camiones-2.jpg',
    '/images/mantas-cobertores-toldos-camiones-3.jpg',
    '/images/mantas-cobertores-toldos-camiones-4.jpg',
  ],
*/

// --- siders-tolderas-camiones ---
/*
  image: '/images/siders-tolderas-camiones-1.jpg',
  gallery: [
    '/images/siders-tolderas-camiones-1.jpg',
    '/images/siders-tolderas-camiones-2.jpg',
    '/images/siders-tolderas-camiones-3.jpg',
    '/images/siders-tolderas-camiones-4.jpg',
  ],
*/

// --- cobertores-agricolas-multimaterial ---
/*
  image: '/images/cobertores-agricolas-multimaterial-1.jpg',
  gallery: [
    '/images/cobertores-agricolas-multimaterial-1.jpg',
    '/images/cobertores-agricolas-multimaterial-2.jpg',
    '/images/cobertores-agricolas-multimaterial-3.jpg',
    '/images/cobertores-agricolas-multimaterial-4.jpg',
  ],
*/

// --- mantas-arpilleras-granjas ---
/*
  image: '/images/mantas-arpilleras-granjas-1.jpg',
  gallery: [
    '/images/mantas-arpilleras-granjas-1.jpg',
    '/images/mantas-arpilleras-granjas-2.jpg',
    '/images/mantas-arpilleras-granjas-3.jpg',
    '/images/mantas-arpilleras-granjas-4.jpg',
  ],
*/

// --- mantas-aislantes-termicas-termoacusticas ---
/*
  image: '/images/mantas-aislantes-termicas-termoacusticas-1.jpg',
  gallery: [
    '/images/mantas-aislantes-termicas-termoacusticas-1.jpg',
    '/images/mantas-aislantes-termicas-termoacusticas-2.jpg',
    '/images/mantas-aislantes-termicas-termoacusticas-3.jpg',
    '/images/mantas-aislantes-termicas-termoacusticas-4.jpg',
  ],
*/
