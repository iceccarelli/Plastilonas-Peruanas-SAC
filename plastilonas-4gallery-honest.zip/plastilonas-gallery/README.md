# Plastilonas Peruanas SAC — 4-image gallery fill (honest cards)

**Commit baseline:** `9cc09fa` (main)  
**Integrity:** Zero photorealistic fabrication. Only (a) existing real company photos kept as-is, (b) no crops performed (no additional source photos supplied in `incoming-photos/`), (c) branded non-photographic diagram/spec cards for every remaining slot.

## What this package contains

```
public/images/          # 93 new JPEGs (1200×900, 4:3, sRGB, progressive mozjpeg q80, EXIF+ICC stripped)
scripts/
  generate-cards.mjs    # source that produced the cards (re-runnable)
  codemod-galleries.mjs # idempotent Node codemod — matches by slug, aborts on mismatch
manifest.json           # slug → { gallery[4], tags[real|card], primary }
README.md               # this file
```

**Total added weight:** ~0.4 MB (text-heavy schematic cards compress extremely well).

## Apply steps (from a clean checkout of main @ 9cc09fa)

```bash
# 1. Copy the new images
cp -n public/images/*.jpg  <repo>/public/images/
# (or rsync -av --ignore-existing)

# 2. Run the codemod from the repository root
node <path-to>/scripts/codemod-galleries.mjs \
  --manifest=<path-to>/manifest.json \
  --products=lib/products.ts

# 3. Verify
npx tsc --noEmit
npm run build
```

The codemod:

- Touches **only** `products[]` entries matched by unique `slug`.
- Sets `gallery` to exactly the 4 paths listed in the manifest (real primary first).
- Leaves `image` (and every other field) untouched.
- Leaves `productFamilies` / `families[]` completely untouched.
- Aborts loudly if any expected slug is missing or a gallery ends up ≠ 4 items.
- Is idempotent: re-running produces an identical `products.ts`.

## Optional Ken-Burns upgrade (not included)

The cards already have ≥12 % inner safe margin so the existing uniform `ken-burns` class does not clip text.  
If you later want to omit the class on card slides, add a `kind: 'photo' | 'card'` to gallery entries and condition the class in `ProductRotator.tsx`. That change is **not** shipped here so the drop-in stays minimal and the build stays green without further type edits.

## Verification checklist (already performed on the generated assets)

- [x] 34 products, every `gallery.length === 4`
- [x] Slide 1 / `image` is always a real existing photo (never a card)
- [x] Every gallery path resolves under `public/images/`
- [x] All new files share identical 1200×900 sRGB progressive JPEG geometry
- [x] No photorealistic / AI-generated product imagery
- [x] `families` / `productFamilies` untouched by design

## STILL NEEDS REAL PHOTOGRAPHY

Every product that still relies on ≥ 1 card (i.e. almost the whole catalogue).  
Priority order for the operator: shoot genuine detail / alternate-framing photos of the SKUs that currently have only a single real image, then re-run a crop pass and replace the corresponding cards.

Full list (slug · #cards remaining):

- geomembranas-pvc · 3
- mallas-antiafidas · 3
- mantas-cobertores-toldos-camiones · 3
- mantas-arpilleras-granjas · 3
- mantas-aislantes-termicas-termoacusticas · 3
- mulch-madera-picada · 3
- sacos-polytarp-embarque-granel · 3
- bolsas-laminas-pebd-pead · 3
- films-termocontraibles-shrink · 3
- siders-tolderas-camiones · 3
- cobertores-agricolas-multimaterial · 3
- coberturas-inflables · 3
- modulos-albergues-campamentos · 3
- galpones-invernaderos-estructurados · 3
- toldos-cerramientos · 3
- malla-raschel-sombra · 3
- malla-anti-pajaro-anti-granizo · 3
- geomembrana-polietileno-pe-hdpe · 3
- geomembrana-pe-fortificada · 3
- geomembrana-bituminosa · 3
- geotextiles · 3
- geomallas-geogrids · 3
- tanques-flexibles-bladders · 3
- biodigestores · 3
- tuberias-hdpe · 3
- gigantografias-senaletica · 3
- revestimiento-vehicular-toldos-publicitarios · 3
- big-bags-bolsones-polipropileno · 2
- biombos-protectores-soldadura · 2
- lona-plastificada-rafia-polytarp · 2
- coberturas-tensionadas-arquitectura-textil · 2
- accesorios-instalacion · 2
- carpas-lona-estructuras-metalicas · 1
- mangas-ventilacion-minas-tuneles · 1

When real photos arrive, place them under `incoming-photos/<slug>/`, re-run a normaliser that respects the integrity rule (no upscaling, genuine crops only), then update the manifest and re-apply the codemod.
